-- MySQL dump 10.13  Distrib 8.0.45, for Linux (aarch64)
--
-- Host: localhost    Database: material_system_react
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `component_token`
--

DROP TABLE IF EXISTS `component_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `component_token` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `component_name` varchar(100) NOT NULL COMMENT '组件名称',
  `token_key` varchar(100) NOT NULL COMMENT 'Token键名',
  `token_type` varchar(20) NOT NULL COMMENT 'Token类型',
  `default_light_value` varchar(500) DEFAULT NULL COMMENT '默认亮色值',
  `default_dark_value` varchar(500) DEFAULT NULL COMMENT '默认暗色值',
  `current_light_value` varchar(500) DEFAULT NULL COMMENT '当前亮色值',
  `current_dark_value` varchar(500) DEFAULT NULL COMMENT '当前暗色值',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `sort_order` int DEFAULT '0' COMMENT '排序',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_component_name` (`component_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='组件级 Design Token 表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `component_token`
--

LOCK TABLES `component_token` WRITE;
/*!40000 ALTER TABLE `component_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `component_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `construction_application`
--

DROP TABLE IF EXISTS `construction_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `construction_application` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `application_no` varchar(50) NOT NULL COMMENT '申请单号',
  `construction_name` varchar(200) NOT NULL COMMENT '施工项名称',
  `content` text COMMENT '施工内容',
  `status` varchar(20) NOT NULL DEFAULT 'draft' COMMENT '状态: draft/pending/approved/rejected',
  `quantity` decimal(15,4) DEFAULT '0.0000' COMMENT '申请数量',
  `budget` decimal(15,2) DEFAULT NULL COMMENT '预算',
  `applicant` varchar(50) DEFAULT NULL COMMENT '申请人',
  `apply_time` datetime DEFAULT NULL COMMENT '申请时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_application_no` (`application_no`),
  KEY `idx_status_apply_time` (`status`,`apply_time`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='施工申请表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `construction_application`
--

LOCK TABLES `construction_application` WRITE;
/*!40000 ALTER TABLE `construction_application` DISABLE KEYS */;
INSERT INTO `construction_application` VALUES (1,'CA202604220001','基础开挖工程','A栋楼地基土方开挖','approved',1.0000,50000.00,'张三','2026-04-22 08:30:00','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(2,'CA202604220002','钢筋绑扎工程','地下室钢筋绑扎施工','pending',1.0000,80000.00,'李四','2026-04-22 09:00:00','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(3,'CA202604220003','混凝土浇筑','一层楼板混凝土浇筑','draft',1.0000,120000.00,'王五','2026-04-22 10:00:00','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(4,'CA202604220004','防水施工','屋面防水卷材铺设','approved',1.0000,35000.00,'赵六','2026-04-22 11:00:00','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(5,'CA202604220005','外墙保温','外墙外保温系统安装','rejected',1.0000,65000.00,'张三','2026-04-22 14:00:00','2026-06-04 07:03:29','2026-06-04 07:03:29',0);
/*!40000 ALTER TABLE `construction_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftsman`
--

DROP TABLE IF EXISTS `craftsman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftsman` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `craftsman_code` varchar(50) NOT NULL COMMENT '工匠编码',
  `name` varchar(100) NOT NULL COMMENT '姓名',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `user_account` varchar(100) DEFAULT NULL COMMENT '用户账号',
  `service_provider_name` varchar(200) DEFAULT NULL COMMENT '服务商名称',
  `type` varchar(20) DEFAULT 'company' COMMENT '类型：person个人 company服务商',
  `region` varchar(100) DEFAULT NULL COMMENT '区域',
  `status` tinyint DEFAULT '1' COMMENT '状态：1启用 0禁用',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_craftsman_code` (`craftsman_code`),
  KEY `idx_name` (`name`),
  KEY `idx_phone` (`phone`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工匠表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftsman`
--

LOCK TABLES `craftsman` WRITE;
/*!40000 ALTER TABLE `craftsman` DISABLE KEYS */;
INSERT INTO `craftsman` VALUES (1,'CM20260001','张建国','13800138001','zhangjg','北京建工集团有限公司','company','华北',1,'2026-06-04 07:03:29','2026-06-09 03:20:21',0),(2,'CM20260002','李明辉','13800138002','limh','上海建工集团','company','华东',1,'2026-06-04 07:03:29','2026-06-09 03:20:21',0),(3,'CM20260003','王大力','13800138003','wangdl','广州建筑股份有限公司 / 第三分公司','company','华南',1,'2026-06-04 07:03:29','2026-06-09 03:20:21',0),(4,'CM20260004','赵铁柱','13800138004','zhaotz','深圳建筑工程公司','person','华南',0,'2026-06-04 07:03:29','2026-06-09 03:20:21',0),(5,'CM20260005','刘金宝','13800138005','liujb','成都建工集团','company','西南',1,'2026-06-04 07:03:29','2026-06-09 03:20:21',0);
/*!40000 ALTER TABLE `craftsman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftsman_view`
--

DROP TABLE IF EXISTS `craftsman_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftsman_view` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(100) NOT NULL COMMENT '视图名称',
  `filters` text COMMENT '筛选条件JSON',
  `filter_order` text COMMENT '筛选顺序JSON',
  `user_id` varchar(100) DEFAULT 'default' COMMENT '用户ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工匠视图表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftsman_view`
--

LOCK TABLES `craftsman_view` WRITE;
/*!40000 ALTER TABLE `craftsman_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftsman_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `design_token`
--

DROP TABLE IF EXISTS `design_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `design_token` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `category_id` bigint NOT NULL COMMENT '分类ID',
  `name` varchar(100) NOT NULL COMMENT 'Token名称',
  `token_key` varchar(100) NOT NULL COMMENT 'Token键名',
  `token_type` varchar(20) NOT NULL COMMENT 'Token类型: color/number/text/shadow',
  `default_value` varchar(500) NOT NULL COMMENT '默认值',
  `current_value` varchar(500) NOT NULL COMMENT '当前值',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `is_ant_design_token` tinyint DEFAULT '0' COMMENT '是否为Ant Design Token',
  `ant_design_token_name` varchar(100) DEFAULT NULL COMMENT 'Ant Design Token名称',
  `sort_order` int DEFAULT '0' COMMENT '排序',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_token_key` (`token_key`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Design Token 表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `design_token`
--

LOCK TABLES `design_token` WRITE;
/*!40000 ALTER TABLE `design_token` DISABLE KEYS */;
INSERT INTO `design_token` VALUES (1,1,'基础1','--primary-1','color','#FFF2E8','#FFF2E8','主色色阶',0,NULL,1,'2026-06-04 07:03:29'),(2,1,'基础2','--primary-2','color','#FFDCD1','#FFDCD1','主色色阶',0,NULL,2,'2026-06-04 07:03:29'),(3,1,'基础3','--primary-3','color','#FFBBA8','#FFBBA8','主色色阶',0,NULL,3,'2026-06-04 07:03:29'),(4,1,'基础4','--primary-4','color','#FF997F','#FF997F','主色色阶',0,NULL,4,'2026-06-04 07:03:29'),(5,1,'基础5','--primary-5','color','#FF7756','#FF7756','主色色阶',0,NULL,5,'2026-06-04 07:03:29'),(6,1,'基础6','--primary-6','color','#F95914','#F95914','主色色阶',0,NULL,6,'2026-06-04 07:03:29'),(7,1,'基础7','--primary-7','color','#E64A19','#E64A19','主色色阶',0,NULL,7,'2026-06-04 07:03:29'),(8,1,'基础8','--primary-8','color','#CC3D10','#CC3D10','主色色阶',0,NULL,8,'2026-06-04 07:03:29'),(9,1,'基础9','--primary-9','color','#993008','#993008','主色色阶',0,NULL,9,'2026-06-04 07:03:29'),(10,1,'基础10','--primary-10','color','#662300','#662300','主色色阶',0,NULL,10,'2026-06-04 07:03:29'),(11,1,'成功1','--success-1','color','#F6FFED','#F6FFED','成功色色阶',0,NULL,11,'2026-06-04 07:03:29'),(12,1,'成功2','--success-2','color','#D9F7BE','#D9F7BE','成功色色阶',0,NULL,12,'2026-06-04 07:03:29'),(13,1,'成功3','--success-3','color','#B7EB8F','#B7EB8F','成功色色阶',0,NULL,13,'2026-06-04 07:03:29'),(14,1,'成功4','--success-4','color','#95DE64','#95DE64','成功色色阶',0,NULL,14,'2026-06-04 07:03:29'),(15,1,'成功5','--success-5','color','#73D13D','#73D13D','成功色色阶',0,NULL,15,'2026-06-04 07:03:29'),(16,1,'成功6','--success-6','color','#52C41A','#52C41A','成功色色阶',0,NULL,16,'2026-06-04 07:03:29'),(17,1,'成功7','--success-7','color','#389E0D','#389E0D','成功色色阶',0,NULL,17,'2026-06-04 07:03:29'),(18,1,'成功8','--success-8','color','#237804','#237804','成功色色阶',0,NULL,18,'2026-06-04 07:03:29'),(19,1,'成功9','--success-9','color','#135200','#135200','成功色色阶',0,NULL,19,'2026-06-04 07:03:29'),(20,1,'成功10','--success-10','color','#092B00','#092B00','成功色色阶',0,NULL,20,'2026-06-04 07:03:29'),(21,1,'警告1','--warning-1','color','#FFFBE6','#FFFBE6','警告色色阶',0,NULL,21,'2026-06-04 07:03:29'),(22,1,'警告2','--warning-2','color','#FFF1B8','#FFF1B8','警告色色阶',0,NULL,22,'2026-06-04 07:03:29'),(23,1,'警告3','--warning-3','color','#FFE58F','#FFE58F','警告色色阶',0,NULL,23,'2026-06-04 07:03:29'),(24,1,'警告4','--warning-4','color','#FFD666','#FFD666','警告色色阶',0,NULL,24,'2026-06-04 07:03:29'),(25,1,'警告5','--warning-5','color','#FFC53D','#FFC53D','警告色色阶',0,NULL,25,'2026-06-04 07:03:29'),(26,1,'警告6','--warning-6','color','#FAAD14','#FAAD14','警告色色阶',0,NULL,26,'2026-06-04 07:03:29'),(27,1,'警告7','--warning-7','color','#D9960E','#D9960E','警告色色阶',0,NULL,27,'2026-06-04 07:03:29'),(28,1,'警告8','--warning-8','color','#B88008','#B88008','警告色色阶',0,NULL,28,'2026-06-04 07:03:29'),(29,1,'警告9','--warning-9','color','#996A04','#996A04','警告色色阶',0,NULL,29,'2026-06-04 07:03:29'),(30,1,'警告10','--warning-10','color','#7A5402','#7A5402','警告色色阶',0,NULL,30,'2026-06-04 07:03:29'),(31,1,'错误1','--error-1','color','#FFF2F0','#FFF2F0','错误色色阶',0,NULL,31,'2026-06-04 07:03:29'),(32,1,'错误2','--error-2','color','#FFD8D6','#FFD8D6','错误色色阶',0,NULL,32,'2026-06-04 07:03:29'),(33,1,'错误3','--error-3','color','#FFB3B0','#FFB3B0','错误色色阶',0,NULL,33,'2026-06-04 07:03:29'),(34,1,'错误4','--error-4','color','#FF8E8A','#FF8E8A','错误色色阶',0,NULL,34,'2026-06-04 07:03:29'),(35,1,'错误5','--error-5','color','#FF6A66','#FF6A66','错误色色阶',0,NULL,35,'2026-06-04 07:03:29'),(36,1,'错误6','--error-6','color','#FF4D4F','#FF4D4F','错误色色阶',0,NULL,36,'2026-06-04 07:03:29'),(37,1,'错误7','--error-7','color','#E8383A','#E8383A','错误色色阶',0,NULL,37,'2026-06-04 07:03:29'),(38,1,'错误8','--error-8','color','#D12426','#D12426','错误色色阶',0,NULL,38,'2026-06-04 07:03:29'),(39,1,'错误9','--error-9','color','#B81214','#B81214','错误色色阶',0,NULL,39,'2026-06-04 07:03:29'),(40,1,'错误10','--error-10','color','#A00000','#A00000','错误色色阶',0,NULL,40,'2026-06-04 07:03:29'),(41,1,'信息1','--info-1','color','#F0F5FF','#F0F5FF','信息色色阶',0,NULL,41,'2026-06-04 07:03:29'),(42,1,'信息2','--info-2','color','#D6E8FF','#D6E8FF','信息色色阶',0,NULL,42,'2026-06-04 07:03:29'),(43,1,'信息3','--info-3','color','#ADC8FF','#ADC8FF','信息色色阶',0,NULL,43,'2026-06-04 07:03:29'),(44,1,'信息4','--info-4','color','#85A8FF','#85A8FF','信息色色阶',0,NULL,44,'2026-06-04 07:03:29'),(45,1,'信息5','--info-5','color','#5D89FF','#5D89FF','信息色色阶',0,NULL,45,'2026-06-04 07:03:29'),(46,1,'信息6','--info-6','color','#1677FF','#1677FF','信息色色阶',0,NULL,46,'2026-06-04 07:03:29'),(47,1,'信息7','--info-7','color','#095ED9','#095ED9','信息色色阶',0,NULL,47,'2026-06-04 07:03:29'),(48,1,'信息8','--info-8','color','#0047B3','#0047B3','信息色色阶',0,NULL,48,'2026-06-04 07:03:29'),(49,1,'信息9','--info-9','color','#00348C','#00348C','信息色色阶',0,NULL,49,'2026-06-04 07:03:29'),(50,1,'信息10','--info-10','color','#002266','#002266','信息色色阶',0,NULL,50,'2026-06-04 07:03:29'),(51,2,'主色','--primary-color','color','#F95914','#F95914','主题主色',1,'colorPrimary',1,'2026-06-04 07:03:29'),(52,2,'主色悬浮态','--primary-hover','color','#FF7043','#FF7043','主色悬浮态',1,'colorPrimaryHover',2,'2026-06-04 07:03:29'),(53,2,'主色激活态','--primary-active','color','#E64A19','#E64A19','主色激活态',1,'colorPrimaryActive',3,'2026-06-04 07:03:29'),(54,2,'主色背景','--primary-bg','color','#FFF2E8','#FFF2E8','主色背景色',0,NULL,4,'2026-06-04 07:03:29'),(55,2,'主色边框','--primary-border','color','#FFDCD1','#FFDCD1','主色边框色',0,NULL,5,'2026-06-04 07:03:29'),(56,2,'主色文本','--primary-text','color','#F95914','#F95914','主色文本色',0,NULL,6,'2026-06-04 07:03:29'),(57,2,'主色浅背景','--primary-bg-light','color','#FFF7F0','#FFF7F0','主色浅背景色',0,NULL,7,'2026-06-04 07:03:29'),(58,2,'成功背景色','--color-success-bg','color','#f6ffed','#f6ffed','成功状态背景色',0,NULL,8,'2026-06-04 07:03:29'),(59,2,'警告背景色','--color-warning-bg','color','#fffbE6','#fffbE6','警告状态背景色',0,NULL,9,'2026-06-04 07:03:29'),(60,2,'错误背景色','--color-error-bg','color','#fff2f0','#fff2f0','错误状态背景色',0,NULL,10,'2026-06-04 07:03:29'),(61,2,'信息背景色','--color-info-bg','color','#e6f4ff','#e6f4ff','信息状态背景色',0,NULL,11,'2026-06-04 07:03:29'),(62,2,'成功边框色','--color-success-border','color','#b7eb8f','#b7eb8f','成功状态边框色',0,NULL,12,'2026-06-04 07:03:29'),(63,2,'警告边框色','--color-warning-border','color','#ffe58f','#ffe58f','警告状态边框色',0,NULL,13,'2026-06-04 07:03:29'),(64,2,'错误边框色','--color-error-border','color','#ffccc7','#ffccc7','错误状态边框色',0,NULL,14,'2026-06-04 07:03:29'),(65,2,'信息边框色','--color-info-border','color','#91caff','#91caff','信息状态边框色',0,NULL,15,'2026-06-04 07:03:29'),(66,2,'主文本色','--color-text','color','#000000e6','#000000e6','主要文本色',1,'colorText',16,'2026-06-04 07:03:29'),(67,2,'次要文本色','--color-text-secondary','color','#00000073','#00000073','次要文本色',1,'colorTextSecondary',17,'2026-06-04 07:03:29'),(68,2,'占位文本色','--color-text-tertiary','color','#00000047','#00000047','占位文本色',0,NULL,18,'2026-06-04 07:03:29'),(69,2,'禁用文本色','--color-text-quaternary','color','#00000026','#00000026','禁用文本色',0,NULL,19,'2026-06-04 07:03:29'),(70,2,'容器背景色','--color-bg-container','color','#ffffff','#ffffff','容器背景色',1,'colorBgContainer',20,'2026-06-04 07:03:29'),(71,2,'布局背景色','--color-bg-layout','color','#f5f5f5','#f5f5f5','布局背景色',1,'colorBgLayout',21,'2026-06-04 07:03:29'),(72,2,'抬升背景色','--color-bg-elevated','color','#ffffff','#ffffff','卡片、弹窗等抬升元素背景',0,NULL,22,'2026-06-04 07:03:29'),(73,2,'遮罩背景色','--color-bg-mask','color','rgba(0, 0, 0, 0.45)','rgba(0, 0, 0, 0.45)','遮罩背景色',0,NULL,23,'2026-06-04 07:03:29'),(74,2,'边框色','--color-border','color','#d9d9d9','#d9d9d9','边框色',1,'colorBorder',24,'2026-06-04 07:03:29'),(75,2,'次要边框色','--color-border-secondary','color','#f0f0f0','#f0f0f0','次要边框色',1,'colorBorderSecondary',25,'2026-06-04 07:03:29'),(76,3,'字体家族','--font-family','text','\'PingFang SC\', -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif','\'PingFang SC\', -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif','字体家族',1,'fontFamily',1,'2026-06-04 07:03:29'),(77,3,'代码字体','--font-family-code','text','\'SFMono-Regular\', Consolas, \'Liberation Mono\', Menlo, Courier, monospace','\'SFMono-Regular\', Consolas, \'Liberation Mono\', Menlo\', Courier, monospace','代码字体',0,NULL,2,'2026-06-04 07:03:29'),(78,3,'小字号','--font-size-sm','number','12','12','小字体大小(px)',1,'fontSizeSM',3,'2026-06-04 07:03:29'),(79,3,'基础字号','--font-size-base','number','14','14','基础字体大小(px)',1,'fontSize',4,'2026-06-04 07:03:29'),(80,3,'大字号','--font-size-lg','number','16','16','大字体大小(px)',1,'fontSizeLG',5,'2026-06-04 07:03:29'),(81,3,'标题1字号','--font-size-h1','number','38','38','标题1字体大小(px)',1,'fontSizeHeading1',6,'2026-06-04 07:03:29'),(82,3,'标题2字号','--font-size-h2','number','30','30','标题2字体大小(px)',1,'fontSizeHeading2',7,'2026-06-04 07:03:29'),(83,3,'标题3字号','--font-size-h3','number','24','24','标题3字体大小(px)',1,'fontSizeHeading3',8,'2026-06-04 07:03:29'),(84,3,'标题4字号','--font-size-h4','number','20','20','标题4字体大小(px)',1,'fontSizeHeading4',9,'2026-06-04 07:03:29'),(85,3,'行高','--line-height','number','1.5714','1.5714','行高',1,'lineHeight',10,'2026-06-04 07:03:29'),(86,4,'间距 XXS','--spacing-xxs','number','4','4','超小间距(px)',0,NULL,1,'2026-06-04 07:03:29'),(87,4,'间距 XS','--spacing-xs','number','8','8','小间距(px)',0,NULL,2,'2026-06-04 07:03:29'),(88,4,'间距 SM','--spacing-sm','number','12','12','中小间距(px)',0,NULL,3,'2026-06-04 07:03:29'),(89,4,'间距 MD','--spacing-md','number','16','16','中间距(px)',0,NULL,4,'2026-06-04 07:03:29'),(90,4,'间距 LG','--spacing-lg','number','24','24','大间距(px)',0,NULL,5,'2026-06-04 07:03:29'),(91,4,'间距 XL','--spacing-xl','number','32','32','超大间距(px)',0,NULL,6,'2026-06-04 07:03:29'),(92,5,'基础圆角','--border-radius-base','number','6','6','基础圆角大小(px)',1,'borderRadius',1,'2026-06-04 07:03:29'),(93,5,'小圆角','--border-radius-sm','number','4','4','小圆角(px)',1,'borderRadiusSM',2,'2026-06-04 07:03:29'),(94,5,'大圆角','--border-radius-lg','number','8','8','大圆角(px)',1,'borderRadiusLG',3,'2026-06-04 07:03:29'),(95,5,'超小圆角','--border-radius-xs','number','2','2','超小圆角(px)',0,NULL,4,'2026-06-04 07:03:29'),(96,5,'圆形','--border-radius-circle','text','50%','50%','圆形（用于头像等）',0,NULL,5,'2026-06-04 07:03:29'),(97,5,'边框宽度','--border-width','number','1','1','边框宽度(px)',0,NULL,6,'2026-06-04 07:03:29'),(98,6,'小阴影','--shadow-sm','shadow','0 1px 2px rgba(0, 0, 0, 0.03), 0 1px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px 0 rgba(0, 0, 0, 0.02)','0 1px 2px rgba(0, 0, 0, 0.03), 0 1px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px 0 rgba(0, 0, 0, 0.02)','小阴影',0,NULL,1,'2026-06-04 07:03:29'),(99,6,'中等阴影','--shadow-md','shadow','0 4px 12px rgba(0, 0, 0, 0.08)','0 4px 12px rgba(0, 0, 0, 0.08)','中等阴影',0,NULL,2,'2026-06-04 07:03:29'),(100,6,'大阴影','--shadow-lg','shadow','0 6px 16px rgba(0, 0, 0, 0.08), 0 3px 6px -4px rgba(0, 0, 0, 0.12), 0 9px 28px 8px rgba(0, 0, 0, 0.05)','0 6px 16px rgba(0, 0, 0, 0.08), 0 3px 6px -4px rgba(0, 0, 0, 0.12), 0 9px 28px 8px rgba(0, 0, 0, 0.05)','大阴影',0,NULL,3,'2026-06-04 07:03:29'),(101,6,'浮层阴影','--shadow-elevated','shadow','0 9px 28px 8px rgba(0, 0, 0, 0.05), 0 6px 16px rgba(0, 0, 0, 0.08)','0 9px 28px 8px rgba(0, 0, 0, 0.05), 0 6px 16px rgba(0, 0, 0, 0.08)','浮层阴影（弹窗等）',0,NULL,4,'2026-06-04 07:03:29'),(102,7,'快速动画时长','--motion-duration-fast','text','0.1s','0.1s','快速动画时长，如 hover 效果',0,NULL,1,'2026-06-04 07:03:29'),(103,7,'中等动画时长','--motion-duration-mid','text','0.2s','0.2s','中等动画时长，如展开收起',0,NULL,2,'2026-06-04 07:03:29'),(104,7,'慢速动画时长','--motion-duration-slow','text','0.3s','0.3s','慢速动画时长，如页面切换',0,NULL,3,'2026-06-04 07:03:29'),(105,7,'缓入缓出','--motion-ease-in-out','text','cubic-bezier(0.645, 0.045, 0.355, 1.000)','cubic-bezier(0.645, 0.045, 0.355, 1.000)','缓入缓出动画曲线',0,NULL,4,'2026-06-04 07:03:29'),(106,7,'缓出','--motion-ease-out','text','cubic-bezier(0.215, 0.610, 0.355, 1.000)','cubic-bezier(0.215, 0.610, 0.355, 1.000)','缓出动画曲线',0,NULL,5,'2026-06-04 07:03:29'),(107,7,'缓入','--motion-ease-in','text','cubic-bezier(0.550, 0.055, 0.675, 0.190)','cubic-bezier(0.550, 0.055, 0.675, 0.190)','缓入动画曲线',0,NULL,6,'2026-06-04 07:03:29'),(108,7,'线性','--motion-linear','text','linear','linear','线性动画曲线',0,NULL,7,'2026-06-04 07:03:29'),(109,7,'弹跳','--motion-bounce','text','cubic-bezier(0.680, -0.550, 0.265, 1.550)','cubic-bezier(0.680, -0.550, 0.265, 1.550)','弹跳动画曲线',0,NULL,8,'2026-06-04 07:03:29');
/*!40000 ALTER TABLE `design_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `design_token_category`
--

DROP TABLE IF EXISTS `design_token_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `design_token_category` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(50) NOT NULL COMMENT '分类名称',
  `description` varchar(255) DEFAULT NULL COMMENT '分类描述',
  `code` varchar(50) NOT NULL COMMENT '分类标识',
  `sort_order` int DEFAULT '0' COMMENT '排序',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Design Token 分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `design_token_category`
--

LOCK TABLES `design_token_category` WRITE;
/*!40000 ALTER TABLE `design_token_category` DISABLE KEYS */;
INSERT INTO `design_token_category` VALUES (1,'基础色阶',NULL,'base-color',1,'2026-06-04 07:03:29'),(2,'颜色',NULL,'color',2,'2026-06-04 07:03:29'),(3,'字体',NULL,'typography',3,'2026-06-04 07:03:29'),(4,'间距',NULL,'spacing',4,'2026-06-04 07:03:29'),(5,'边框',NULL,'border',5,'2026-06-04 07:03:29'),(6,'阴影',NULL,'shadow',6,'2026-06-04 07:03:29'),(7,'动效',NULL,'motion',7,'2026-06-04 07:03:29');
/*!40000 ALTER TABLE `design_token_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite`
--

DROP TABLE IF EXISTS `favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorite` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` bigint NOT NULL DEFAULT '1' COMMENT '用户ID',
  `menu_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '菜单key',
  `menu_label` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '菜单名称',
  `menu_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜单路径',
  `sort` int DEFAULT '0' COMMENT '排序',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_menu` (`user_id`,`menu_key`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='收藏表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite`
--

LOCK TABLES `favorite` WRITE;
/*!40000 ALTER TABLE `favorite` DISABLE KEYS */;
INSERT INTO `favorite` VALUES (1,1,'material-apply','材料申请','/materials',0,'2026-06-09 02:39:00','2026-06-09 02:39:00');
/*!40000 ALTER TABLE `favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `icon_config`
--

DROP TABLE IF EXISTS `icon_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `icon_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图标类型: preset(预设), custom(自定义)',
  `value` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图标标识',
  `label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图标名称',
  `sort_order` int DEFAULT '0' COMMENT '排序',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_value` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='图标配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `icon_config`
--

LOCK TABLES `icon_config` WRITE;
/*!40000 ALTER TABLE `icon_config` DISABLE KEYS */;
INSERT INTO `icon_config` VALUES (1,'preset','home','首页',1,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(2,'preset','star','收藏',2,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(3,'preset','shopping-cart-del','购物车',3,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(4,'preset','setting','设置',4,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(5,'preset','list','列表',6,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(6,'preset','buy','采购',7,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(7,'preset','commodity','商品',8,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(8,'preset','coupon','优惠券',9,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(9,'preset','wallet','钱包',10,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(10,'preset','bank-card','银行卡',11,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(11,'preset','bill','账单',12,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(12,'preset','financing','融资',13,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(13,'preset','transaction','交易',14,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(14,'preset','receive','收款',15,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(15,'preset','building-one','建筑',16,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(16,'preset','user','用户',17,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(17,'preset','file','文件',18,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(18,'preset','search','搜索',19,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(19,'preset','safe','安全',20,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(20,'preset','tool','工具',21,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(21,'preset','app','应用',22,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(22,'preset','find','查找',23,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(23,'preset','people-top-card','用户卡片',24,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(24,'preset','file-cabinet','文件柜',25,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(25,'preset','message-security','安全消息',26,'2026-06-04 07:03:29','2026-06-04 07:03:29'),(26,'preset','all-application','全部应用',27,'2026-06-04 07:03:29','2026-06-04 07:03:29');
/*!40000 ALTER TABLE `icon_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_application`
--

DROP TABLE IF EXISTS `material_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_application` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `application_no` varchar(50) DEFAULT NULL COMMENT '申请单号',
  `material_name` varchar(255) DEFAULT NULL COMMENT '材料名称',
  `spec` varchar(100) DEFAULT NULL COMMENT '规格型号',
  `unit` varchar(20) DEFAULT NULL COMMENT '单位',
  `quantity` decimal(12,2) DEFAULT NULL COMMENT '申请数量',
  `material_quantity` decimal(12,2) DEFAULT NULL COMMENT '材料数量',
  `department` varchar(50) DEFAULT NULL COMMENT '部门',
  `supplier` varchar(255) DEFAULT NULL COMMENT '供应商',
  `description` text COMMENT '描述',
  `status` varchar(50) DEFAULT NULL COMMENT '状态',
  `applicant` varchar(100) DEFAULT NULL COMMENT '申请人',
  `apply_time` datetime DEFAULT NULL COMMENT '申请时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='材料申请表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_application`
--

LOCK TABLES `material_application` WRITE;
/*!40000 ALTER TABLE `material_application` DISABLE KEYS */;
INSERT INTO `material_application` VALUES (1,'MA20260411001','水泥','普通硅酸盐水泥 32.5','吨',100.00,NULL,'engineering','华新水泥有限公司','项目施工用','draft','张三','2026-04-10 09:00:00','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(2,'MA20260411002','钢筋','HRB400 螺纹钢筋 Φ12','吨',50.00,NULL,'engineering','宝钢建材','主体结构用','pending','李四','2026-04-09 14:30:00','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(3,'MA20260411003','砂石','中粗河砂','立方米',200.00,NULL,'procurement','本地砂石场','混凝土配合比用','approved','王五','2026-04-08 10:00:00','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(4,'MA20260411004','木材','松木方 5cm×10cm×400cm','立方米',30.00,NULL,'engineering','林业建材','模板支撑用','rejected','赵六','2026-04-07 16:00:00','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(5,'MA20260411005','混凝土','C30 商品混凝土','立方米',500.00,NULL,'engineering','搅拌站A','基础浇筑用','approved','张三','2026-04-06 08:00:00','2026-06-04 07:03:29','2026-06-04 07:03:29',0);
/*!40000 ALTER TABLE `material_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_view`
--

DROP TABLE IF EXISTS `material_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_view` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(50) NOT NULL COMMENT '视图名称',
  `filters` text COMMENT '筛选条件JSON',
  `filter_order` text COMMENT '筛选条件顺序JSON',
  `user_id` varchar(50) NOT NULL COMMENT '用户ID',
  `page_type` varchar(50) NOT NULL DEFAULT 'material-list' COMMENT '页面类型',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_page` (`user_id`,`page_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='视图表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_view`
--

LOCK TABLES `material_view` WRITE;
/*!40000 ALTER TABLE `material_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `material_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_view`
--

DROP TABLE IF EXISTS `menu_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_view` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(50) NOT NULL COMMENT '视图名称',
  `filters` text COMMENT '筛选条件JSON',
  `filter_order` text COMMENT '筛选条件顺序JSON',
  `user_id` varchar(50) NOT NULL COMMENT '用户ID',
  `page_type` varchar(50) NOT NULL DEFAULT 'menu-management' COMMENT '页面类型',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_page` (`user_id`,`page_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='菜单管理视图表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_view`
--

LOCK TABLES `menu_view` WRITE;
/*!40000 ALTER TABLE `menu_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nav_menu`
--

DROP TABLE IF EXISTS `nav_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nav_menu` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `key` varchar(100) DEFAULT NULL COMMENT '菜单Key',
  `label` varchar(100) DEFAULT NULL COMMENT '菜单名称',
  `path` varchar(255) DEFAULT NULL COMMENT '路径',
  `icon` varchar(50) DEFAULT NULL COMMENT '图标',
  `sort` int DEFAULT '0' COMMENT '排序',
  `status` int DEFAULT '1' COMMENT '状态：1启用 0禁用',
  `parent_id` bigint DEFAULT '0' COMMENT '父级ID',
  `level` int DEFAULT '0' COMMENT '层级',
  `menu_type` varchar(50) DEFAULT '业务菜单' COMMENT '菜单类型：业务菜单、系统菜单-上',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='导航菜单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nav_menu`
--

LOCK TABLES `nav_menu` WRITE;
/*!40000 ALTER TABLE `nav_menu` DISABLE KEYS */;
INSERT INTO `nav_menu` VALUES (1,'home','首页','/home','home',1,1,0,0,'系统菜单-上','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(2,'favorites','收藏','/favorites','star',2,1,0,0,'系统菜单-上','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(3,'material-center','材料中心',NULL,'file',3,1,0,0,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(4,'material-apply','材料申请','/materials','list',1,1,3,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(5,'construction-library','施工项库','/construction-library','building-one',2,1,3,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(6,'purchase-center','采购中心',NULL,'buy',2,1,0,0,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(7,'purchase-demand','采购需求单','/purchase-demand','transaction',1,1,6,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(8,'purchase-order','采购订单','/purchase-order','bill',2,1,6,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(9,'product-center','商品中心',NULL,'commodity',3,1,0,0,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(10,'tag-list','标签列表','/tag-list','coupon',1,1,9,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(11,'category-list','分类列表','/category-list','list',2,1,9,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(12,'brand-list','品牌列表','/brand-list','bank-card',3,1,9,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(13,'settings-center','系统中心',NULL,'setting',4,1,0,0,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(14,'menu-management','菜单管理','/menu-management','list',1,1,55,2,'业务菜单','2026-06-04 07:03:29','2026-06-09 02:00:19',0),(15,'domain-manage','域管理','/domain-manage','setting',2,1,55,2,'业务菜单','2026-06-04 07:03:29','2026-06-09 02:00:35',0),(16,'user-management','用户管理','/user-management','user',3,1,13,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(17,'system-settings','系统设置',NULL,'tool',4,1,13,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(18,'permission-query','权限查询','/permission-query','safe',5,1,13,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(19,'super-search','超级搜索',NULL,'search',1,1,0,0,'系统菜单-下','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(20,'construction-apply','施工申请列表','/construction-apply',NULL,1,1,5,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(21,'component-preview','组件预览','/component-preview','app',1,1,17,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(22,'craftsman-center','工匠中心',NULL,'user',8,1,0,0,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(23,'workorder-center','工单管理',NULL,'work-order',1,1,22,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(24,'workorder-pool','工单池','/workorder-pool','list',1,1,23,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(25,'workorder-abnormal','异常工单','/workorder-abnormal','alert',2,1,23,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(26,'workorder-sampling','抽样单管理','/workorder-sampling','check-circle',3,1,23,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(27,'workorder-return-visit','回访查看','/workorder-return-visit','phone',4,1,23,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(28,'workorder-barcode-error','异常条码处理','/workorder-barcode-error','barcode',5,1,23,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(29,'workorder-correction','订正异常查询','/workorder-correction','edit',6,1,23,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(30,'workorder-sn-search','SN码查询','/workorder-sn-search','search',7,1,23,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(31,'config-center','基础配置',NULL,'setting',2,1,22,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(32,'config-fault-phenomenon','故障现象配置','/config-fault-phenomenon','warning',1,1,31,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(33,'config-fault-reason','故障原因配置','/config-fault-reason','info-circle',2,1,31,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(34,'config-repair-measure','维修措施配置','/config-repair-measure','wrench',3,1,31,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(35,'config-repair-parts','维修配件配置','/config-repair-parts','package',4,1,31,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(36,'config-workorder-rule','工单规则设置','/config-workorder-rule','rule',5,1,31,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(37,'config-evaluation','评价设置','/config-evaluation','star',6,1,31,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(38,'config-device-link','设备关联配置','/config-device-link','link',7,1,31,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(39,'quality-center','品质反馈',NULL,'check-square',3,1,22,1,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(40,'quality-feedback-list','品质反馈申请列表','/quality-feedback-list','clipboard',1,1,39,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(41,'quality-batch-list','批次反馈申请列表','/quality-batch-list','layers',2,1,39,2,'业务菜单','2026-06-04 07:03:29','2026-06-04 07:03:29',0),(42,'craftsman-manage','工匠/服务商管理',NULL,'team',4,1,22,1,'业务菜单','2026-06-04 07:03:29','2026-06-09 03:20:21',0),(43,'craftsman-skill','技能管理','/craftsman-skill','award',1,1,42,2,'业务菜单','2026-06-04 07:03:29','2026-06-09 06:53:05',0),(44,'craftsman-application','工匠申请','/craftsman-application','file-application',2,1,42,2,'业务菜单','2026-06-04 07:03:29','2026-06-09 06:53:15',0),(45,'craftsman-search','工匠列表','/craftsman-search','search-user',3,1,42,2,'业务菜单','2026-06-04 07:03:29','2026-06-09 03:20:21',0),(46,'bidding-center','招采中心',NULL,NULL,5,1,0,0,'业务菜单','2026-06-09 01:33:41','2026-06-09 01:33:41',0),(47,'central-stock','中央库存',NULL,NULL,6,1,0,0,'业务菜单','2026-06-09 01:33:41','2026-06-09 01:33:41',0),(48,'customer-center','客户中心',NULL,NULL,7,1,0,0,'业务菜单','2026-06-09 01:33:41','2026-06-09 01:33:41',0),(49,'stock-center','库存中心',NULL,NULL,8,1,0,0,'业务菜单','2026-06-09 01:33:41','2026-06-09 01:33:41',0),(50,'logistics-center','物流中心',NULL,NULL,9,1,0,0,'业务菜单','2026-06-09 01:33:41','2026-06-09 01:33:41',0),(51,'price-center','价格中心',NULL,NULL,10,1,0,0,'业务菜单','2026-06-09 01:33:41','2026-06-09 01:33:41',0),(52,'organization-center','组织中心',NULL,NULL,11,1,0,0,'业务菜单','2026-06-09 01:33:41','2026-06-09 01:33:41',0),(53,'message-center','消息中心',NULL,NULL,12,1,0,0,'业务菜单','2026-06-09 01:33:41','2026-06-09 01:33:41',0),(54,'compare-system','对比系统',NULL,NULL,13,1,0,0,'业务菜单','2026-06-09 01:33:41','2026-06-09 03:15:20',1),(55,'','菜单/域管理','','',0,1,13,1,'业务菜单','2026-06-09 01:59:09','2026-06-09 01:59:19',0);
/*!40000 ALTER TABLE `nav_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_data_permission`
--

DROP TABLE IF EXISTS `sys_data_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_data_permission` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL COMMENT '用户ID（用户级别规则，可为空）',
  `domain_id` bigint DEFAULT NULL COMMENT '域ID（域级别规则，可为空）',
  `menu_key` varchar(50) NOT NULL COMMENT '菜单标识',
  `filter_type` varchar(20) NOT NULL COMMENT '过滤类型：all/self/dept/custom',
  `filter_field` varchar(50) DEFAULT NULL COMMENT '过滤字段',
  `filter_value` varchar(255) DEFAULT NULL COMMENT '过滤值',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_domain_id` (`domain_id`),
  KEY `idx_menu_key` (`menu_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='数据权限规则表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_data_permission`
--

LOCK TABLES `sys_data_permission` WRITE;
/*!40000 ALTER TABLE `sys_data_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_data_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_domain`
--

DROP TABLE IF EXISTS `sys_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_domain` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `domain_key` varchar(50) NOT NULL COMMENT '域标识',
  `domain_name` varchar(100) NOT NULL COMMENT '域名称',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `is_default` tinyint DEFAULT '0' COMMENT '1-默认域(不可调整层级排序) 0-自定义域',
  `status` tinyint DEFAULT '1' COMMENT '1-启用 0-禁用',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `domain_key` (`domain_key`),
  UNIQUE KEY `uk_domain_key` (`domain_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='域表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_domain`
--

LOCK TABLES `sys_domain` WRITE;
/*!40000 ALTER TABLE `sys_domain` DISABLE KEYS */;
INSERT INTO `sys_domain` VALUES (1,'xingjiZM','星际造梦','系统默认域，使用系统默认菜单结构',1,1,'2026-06-04 07:03:29','2026-06-04 07:03:29',0),(2,'gongjiangPT','工匠平台','工匠平台域',0,1,'2026-06-09 01:07:13','2026-06-09 01:07:13',0);
/*!40000 ALTER TABLE `sys_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_domain_menu`
--

DROP TABLE IF EXISTS `sys_domain_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_domain_menu` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `domain_id` bigint NOT NULL COMMENT '域ID',
  `menu_id` bigint NOT NULL COMMENT '菜单ID（关联nav_menu）',
  `custom_label` varchar(100) DEFAULT NULL COMMENT '域内自定义菜单名称（为空使用默认名称）',
  `custom_level` int DEFAULT NULL COMMENT '域内自定义层级（仅自定义域可用，为空继承系统层级）',
  `custom_parent_id` bigint DEFAULT NULL COMMENT '域内自定义父菜单（仅自定义域可用，指向sys_domain_menu.id）',
  `sort` int DEFAULT '0' COMMENT '域内排序（默认域使用系统排序）',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_domain_menu` (`domain_id`,`menu_id`),
  KEY `idx_domain_id` (`domain_id`),
  KEY `idx_menu_id` (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='域-菜单关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_domain_menu`
--

LOCK TABLES `sys_domain_menu` WRITE;
/*!40000 ALTER TABLE `sys_domain_menu` DISABLE KEYS */;
INSERT INTO `sys_domain_menu` VALUES (1,1,1,'首页',NULL,NULL,1,'2026-06-04 07:03:29'),(2,1,2,'收藏',NULL,NULL,2,'2026-06-04 07:03:29'),(3,1,3,'材料中心',NULL,NULL,3,'2026-06-04 07:03:29'),(4,1,4,'材料申请',NULL,NULL,1,'2026-06-04 07:03:29'),(5,1,5,'施工项库',NULL,NULL,2,'2026-06-04 07:03:29'),(6,1,6,'采购中心',NULL,NULL,2,'2026-06-04 07:03:29'),(7,1,7,'采购需求单',NULL,NULL,1,'2026-06-04 07:03:29'),(8,1,8,'采购订单',NULL,NULL,2,'2026-06-04 07:03:29'),(9,1,9,'商品中心',NULL,NULL,3,'2026-06-04 07:03:29'),(10,1,10,'标签列表',NULL,NULL,1,'2026-06-04 07:03:29'),(11,1,11,'分类列表',NULL,NULL,2,'2026-06-04 07:03:29'),(12,1,12,'品牌列表',NULL,NULL,3,'2026-06-04 07:03:29'),(13,1,13,'系统中心',NULL,NULL,4,'2026-06-04 07:03:29'),(14,1,14,'菜单管理',NULL,NULL,1,'2026-06-04 07:03:29'),(15,1,15,'域管理',NULL,NULL,2,'2026-06-04 07:03:29'),(16,1,16,'用户管理',NULL,NULL,3,'2026-06-04 07:03:29'),(17,1,17,'系统设置',NULL,NULL,4,'2026-06-04 07:03:29'),(18,1,18,'权限查询',NULL,NULL,5,'2026-06-04 07:03:29'),(19,1,19,'超级搜索',NULL,NULL,1,'2026-06-04 07:03:29'),(43,1,22,'工匠中心',NULL,NULL,8,'2026-06-09 01:11:02'),(44,1,23,'工单管理',NULL,NULL,1,'2026-06-09 01:11:02'),(45,1,31,'基础配置',NULL,NULL,2,'2026-06-09 01:11:02'),(46,1,39,'品质反馈',NULL,NULL,3,'2026-06-09 01:11:02'),(47,1,42,'工匠/服务商管理',NULL,NULL,4,'2026-06-09 01:11:02'),(48,1,20,'施工申请列表',NULL,NULL,1,'2026-06-09 01:11:02'),(49,1,21,'组件预览',NULL,NULL,1,'2026-06-09 01:11:02'),(50,1,24,'工单池',NULL,NULL,1,'2026-06-09 01:11:02'),(51,1,43,'工匠技能管理',NULL,NULL,1,'2026-06-09 01:11:02'),(52,1,32,'故障现象配置',NULL,NULL,1,'2026-06-09 01:11:02'),(53,1,40,'品质反馈申请列表',NULL,NULL,1,'2026-06-09 01:11:02'),(54,1,25,'异常工单',NULL,NULL,2,'2026-06-09 01:11:02'),(55,1,44,'工匠申请查询',NULL,NULL,2,'2026-06-09 01:11:02'),(56,1,41,'批次反馈申请列表',NULL,NULL,2,'2026-06-09 01:11:02'),(57,1,33,'故障原因配置',NULL,NULL,2,'2026-06-09 01:11:02'),(58,1,45,'工匠列表',NULL,NULL,3,'2026-06-09 01:11:02'),(59,1,34,'维修措施配置',NULL,NULL,3,'2026-06-09 01:11:02'),(60,1,26,'抽样单管理',NULL,NULL,3,'2026-06-09 01:11:02'),(61,1,35,'维修配件配置',NULL,NULL,4,'2026-06-09 01:11:02'),(62,1,27,'回访查看',NULL,NULL,4,'2026-06-09 01:11:02'),(63,1,36,'工单规则设置',NULL,NULL,5,'2026-06-09 01:11:02'),(64,1,28,'异常条码处理',NULL,NULL,5,'2026-06-09 01:11:02'),(65,1,37,'评价设置',NULL,NULL,6,'2026-06-09 01:11:02'),(66,1,29,'订正异常查询',NULL,NULL,6,'2026-06-09 01:11:02'),(67,1,38,'设备关联配置',NULL,NULL,7,'2026-06-09 01:11:02'),(68,1,30,'SN码查询',NULL,NULL,7,'2026-06-09 01:11:02'),(74,1,46,'招采中心',NULL,NULL,5,'2026-06-09 01:33:41'),(75,1,47,'中央库存',NULL,NULL,6,'2026-06-09 01:33:41'),(76,1,48,'客户中心',NULL,NULL,7,'2026-06-09 01:33:41'),(77,1,49,'库存中心',NULL,NULL,8,'2026-06-09 01:33:41'),(78,1,50,'物流中心',NULL,NULL,9,'2026-06-09 01:33:41'),(79,1,51,'价格中心',NULL,NULL,10,'2026-06-09 01:33:41'),(80,1,52,'组织中心',NULL,NULL,11,'2026-06-09 01:33:41'),(81,1,53,'消息中心',NULL,NULL,12,'2026-06-09 01:33:41'),(89,1,55,'菜单/域管理',NULL,NULL,0,'2026-06-09 01:59:09'),(113,2,23,'工单管理',NULL,NULL,1,'2026-06-09 06:53:48'),(114,2,31,'基础配置',NULL,NULL,2,'2026-06-09 06:53:48'),(115,2,39,'品质反馈',NULL,NULL,3,'2026-06-09 06:53:48'),(116,2,42,'工匠/服务商管理',NULL,NULL,4,'2026-06-09 06:53:48'),(117,2,24,'工单池',NULL,NULL,5,'2026-06-09 06:53:48'),(118,2,25,'异常工单',NULL,NULL,6,'2026-06-09 06:53:48'),(119,2,26,'抽样单管理',NULL,NULL,7,'2026-06-09 06:53:48'),(120,2,27,'回访查看',NULL,NULL,8,'2026-06-09 06:53:48'),(121,2,28,'异常条码处理',NULL,NULL,9,'2026-06-09 06:53:48'),(122,2,29,'订正异常查询',NULL,NULL,10,'2026-06-09 06:53:48'),(123,2,30,'SN码查询',NULL,NULL,11,'2026-06-09 06:53:48'),(124,2,32,'故障现象配置',NULL,NULL,12,'2026-06-09 06:53:48'),(125,2,33,'故障原因配置',NULL,NULL,13,'2026-06-09 06:53:48'),(126,2,34,'维修措施配置',NULL,NULL,14,'2026-06-09 06:53:48'),(127,2,35,'维修配件配置',NULL,NULL,15,'2026-06-09 06:53:48'),(128,2,36,'工单规则设置',NULL,NULL,16,'2026-06-09 06:53:48'),(129,2,37,'评价设置',NULL,NULL,17,'2026-06-09 06:53:48'),(130,2,38,'设备关联配置',NULL,NULL,18,'2026-06-09 06:53:48'),(131,2,40,'品质反馈申请列表',NULL,NULL,19,'2026-06-09 06:53:48'),(132,2,41,'批次反馈申请列表',NULL,NULL,20,'2026-06-09 06:53:48'),(133,2,43,'技能管理',NULL,NULL,21,'2026-06-09 06:53:48'),(134,2,44,'工匠申请',NULL,NULL,22,'2026-06-09 06:53:48'),(135,2,45,'工匠列表',NULL,NULL,23,'2026-06-09 06:53:48');
/*!40000 ALTER TABLE `sys_domain_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(255) NOT NULL COMMENT '密码（加密）',
  `nickname` varchar(50) DEFAULT NULL COMMENT '昵称',
  `status` tinyint DEFAULT '1' COMMENT '1-启用 0-禁用',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES (1,'admin','admin123','管理员',1,'2026-06-04 07:03:29','2026-06-04 07:03:29',0);
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_domain`
--

DROP TABLE IF EXISTS `sys_user_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_domain` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `domain_id` bigint NOT NULL COMMENT '域ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_domain` (`user_id`,`domain_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_domain_id` (`domain_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户-域关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_domain`
--

LOCK TABLES `sys_user_domain` WRITE;
/*!40000 ALTER TABLE `sys_user_domain` DISABLE KEYS */;
INSERT INTO `sys_user_domain` VALUES (1,1,1,'2026-06-04 07:03:29');
/*!40000 ALTER TABLE `sys_user_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preference`
--

DROP TABLE IF EXISTS `user_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_preference` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` bigint NOT NULL DEFAULT '1' COMMENT '用户ID',
  `preference_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '偏好键',
  `preference_value` text COLLATE utf8mb4_unicode_ci COMMENT '偏好值',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_key` (`user_id`,`preference_key`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户偏好设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preference`
--

LOCK TABLES `user_preference` WRITE;
/*!40000 ALTER TABLE `user_preference` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_preference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'material_system_react'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-09 18:13:50
